/* zip2glb.js - turns OBJ(+MTL)(+texture maps) bundles, loose or inside .zip files, into binary glTF (.glb).
   Runs entirely in the browser, no libraries needed. Exposes window.Zip2Glb.

   Zip2Glb.expandFiles(File[])           -> entries (unzips any .zip, wraps loose files)
   Zip2Glb.convert(entries, options)     -> [{name, bytes, info}]   (one .glb per .obj found)
     options: {maxTex:2048, onStatus(text), passthrough:['.glb'], images: <backend>}
   Image backend (browser canvas by default): {load(bytes,name)->{w,h,rgba(w,h),dispose()}, encode(rgba,w,h,mime,q)->bytes}
*/
(function (root) {
'use strict';

/* ------------------------------------------------------------------ helpers */
const lower = s => String(s).toLowerCase();
const extOf = n => (String(n).match(/\.[^.\\/]+$/) || [''])[0].toLowerCase();
const baseName = n => String(n).split(/[\\/]+/).pop();
const stemOf = n => baseName(n).replace(/\.[^.]+$/, '');
const IMG_OK = ['.png', '.jpg', '.jpeg', '.webp', '.bmp', '.gif'];
const IMG_BAD = ['.tga', '.dds', '.tif', '.tiff', '.psd', '.exr', '.hdr'];
const u8of = a => new Uint8Array(a.buffer, a.byteOffset, a.byteLength);

/* ------------------------------------------------------------------ zip reader */
async function inflateRaw(u8) {
  if (typeof DecompressionStream === 'undefined')
    throw new Error('This browser cannot unzip files - use a recent Chrome, Edge, Firefox or Safari 16.4+');
  const s = new Blob([u8]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(s).arrayBuffer());
}
function decodeName(b) {
  try { return new TextDecoder('utf-8', { fatal: true }).decode(b); }
  catch (e) { return new TextDecoder('latin1').decode(b); }
}
async function readZip(input) {
  const u8 = input instanceof Uint8Array ? input : new Uint8Array(input);
  const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
  let e = u8.length - 22; const lim = Math.max(0, u8.length - 22 - 65535);
  while (e >= lim && dv.getUint32(e, true) !== 0x06054b50) e--;
  if (e < lim) throw new Error('Not a valid .zip file');
  const n = dv.getUint16(e + 10, true), cd = dv.getUint32(e + 16, true);
  if (n === 0xFFFF || cd === 0xFFFFFFFF) throw new Error('Zip64 archives are not supported');
  const out = []; let p = cd;
  for (let i = 0; i < n; i++) {
    if (dv.getUint32(p, true) !== 0x02014b50) throw new Error('Damaged zip directory');
    const flags = dv.getUint16(p + 8, true), method = dv.getUint16(p + 10, true),
      csz = dv.getUint32(p + 20, true), usz = dv.getUint32(p + 24, true),
      nl = dv.getUint16(p + 28, true), xl = dv.getUint16(p + 30, true), cl = dv.getUint16(p + 32, true),
      lo = dv.getUint32(p + 42, true), name = decodeName(u8.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + xl + cl;
    if (name.endsWith('/') || /(^|\/)__MACOSX\//i.test(name) || /(^|\/)(\._[^/]*|\.DS_Store|Thumbs\.db)$/i.test(name)) continue;
    out.push({
      name, size: usz,
      bytes: async () => {
        if (flags & 1) throw new Error(name + ' is password-protected');
        if (dv.getUint32(lo, true) !== 0x04034b50) throw new Error('Damaged zip entry: ' + name);
        const s = lo + 30 + dv.getUint16(lo + 26, true) + dv.getUint16(lo + 28, true), raw = u8.subarray(s, s + csz);
        if (method === 0) return raw;
        if (method === 8) return inflateRaw(raw);
        throw new Error('Unsupported zip compression (' + method + ') in ' + name);
      }
    });
  }
  return out;
}
/* File[] -> entries; zips are opened, everything else is wrapped as-is */
async function expandFiles(files, onStatus) {
  const out = [];
  for (const f of files) {
    if (extOf(f.name) === '.zip') {
      if (onStatus) onStatus('Opening ' + f.name + '…');
      const list = await readZip(new Uint8Array(await f.arrayBuffer()));
      list.forEach(x => { x.zip = f.name; out.push(x); });
    } else out.push({ name: f.name, size: f.size, bytes: async () => new Uint8Array(await f.arrayBuffer()) });
  }
  return out;
}

/* ------------------------------------------------------------------ OBJ / MTL */
function parseObj(text) {
  const V = [], VT = [], VN = [], cache = new Map(), pos = [], nrm = [], uv = [], vsrc = [], needN = [];
  const prims = new Map(), mtllibs = []; let cur = 'default', grp = null;
  const group = () => grp || (grp = prims.get(cur) || (prims.set(cur, []), prims.get(cur)));
  const corner = tok => {
    const a = tok.split('/'), nv = V.length / 3, nt = VT.length / 2, nn = VN.length / 3;
    const ix = (s, n) => { if (!s) return -1; const i = parseInt(s, 10); return i > 0 ? i - 1 : n + i; };
    const vi = ix(a[0], nv), ti = ix(a[1], nt), ni = ix(a[2], nn), key = vi + '/' + ti + '/' + ni;
    let j = cache.get(key);
    if (j === undefined) {
      j = pos.length / 3; cache.set(key, j);
      pos.push(V[vi * 3], V[vi * 3 + 1], V[vi * 3 + 2]);
      if (ni >= 0) { nrm.push(VN[ni * 3], VN[ni * 3 + 1], VN[ni * 3 + 2]); needN.push(0); } else { nrm.push(0, 0, 0); needN.push(1); }
      if (ti >= 0) uv.push(VT[ti * 2], 1 - VT[ti * 2 + 1]); else uv.push(0, 0);   /* OBJ v is bottom-up, glTF is top-down */
      vsrc.push(vi);
    }
    return j;
  };
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i]; const c = l.charCodeAt(0);
    if (c === 118 /* v */) {
      const p = l.trim().split(/\s+/), t = p[0];
      if (t === 'v') V.push(+p[1], +p[2], +p[3]);
      else if (t === 'vt') VT.push(+p[1], +p[2] || 0);
      else if (t === 'vn') VN.push(+p[1], +p[2], +p[3]);
    } else if (c === 102 /* f */ && l.charCodeAt(1) <= 32) {
      const p = l.trim().split(/\s+/), g = group(), cs = [];
      for (let k = 1; k < p.length; k++) cs.push(corner(p[k]));
      for (let k = 1; k < cs.length - 1; k++) g.push(cs[0], cs[k], cs[k + 1]);   /* fan-triangulate quads / n-gons */
    } else if (l.startsWith('usemtl')) { cur = l.slice(6).trim() || 'default'; grp = null; }
    else if (l.startsWith('mtllib')) mtllibs.push(l.slice(6).trim());
  }
  if (!pos.length || ![...prims.values()].some(g => g.length)) throw new Error('No geometry found in this .obj');
  /* smooth normals for any corner the file gave none for */
  if (needN.some(Boolean)) {
    const acc = new Float64Array(V.length);
    for (const g of prims.values()) for (let t = 0; t < g.length; t += 3) {
      const i0 = g[t], i1 = g[t + 1], i2 = g[t + 2], ax = pos[i1 * 3] - pos[i0 * 3], ay = pos[i1 * 3 + 1] - pos[i0 * 3 + 1], az = pos[i1 * 3 + 2] - pos[i0 * 3 + 2],
        bx = pos[i2 * 3] - pos[i0 * 3], by = pos[i2 * 3 + 1] - pos[i0 * 3 + 1], bz = pos[i2 * 3 + 2] - pos[i0 * 3 + 2],
        nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
      for (const i of [i0, i1, i2]) { const s = vsrc[i] * 3; acc[s] += nx; acc[s + 1] += ny; acc[s + 2] += nz; }
    }
    for (let i = 0; i < needN.length; i++) if (needN[i]) {
      const s = vsrc[i] * 3, l = Math.hypot(acc[s], acc[s + 1], acc[s + 2]) || 1;
      nrm[i * 3] = acc[s] / l; nrm[i * 3 + 1] = acc[s + 1] / l; nrm[i * 3 + 2] = acc[s + 2] / l;
    }
  }
  return { pos: new Float32Array(pos), nrm: new Float32Array(nrm), uv: new Float32Array(uv), prims, mtllibs };
}

function parseMtl(text) {
  const mats = new Map(); let m = null;
  const fileOf = s => baseName(s.trim().replace(/^(?:-\w+(?:\s+-?[\d.]+)+\s+)+/, '')).replace(/^(?:-\w+(?:\s+-?[\d.]+)+\s+)+/, '');
  for (const raw of text.split('\n')) {
    const l = raw.trim(); if (!l || l[0] === '#') continue;
    const sp = l.search(/\s/), k = lower(sp < 0 ? l : l.slice(0, sp)), v = sp < 0 ? '' : l.slice(sp + 1).trim();
    if (k === 'newmtl') { m = { name: v, maps: [] }; mats.set(v, m); }
    else if (!m) continue;
    else if (k === 'kd') { const c = v.split(/\s+/).map(Number); if (c.length >= 3) m.kd = c.slice(0, 3); }
    else if (k === 'd') m.d = +v;
    else if (k === 'tr') m.d = 1 - +v;
    else if (k === 'ns') m.ns = +v;
    else if (/^(map_|bump$|norm$|refl$|disp$|decal$)/.test(k)) m.maps.push([k, fileOf(v)]);
  }
  return mats;
}

/* what does a texture file name say it is? */
function classify(stem) {
  const s = lower(stem).replace(/[^a-z0-9]+/g, '_');
  if (/normal|nrm|(^|_)nor(_|$)/.test(s)) return 'normal';
  if (/gloss|smooth/.test(s)) return 'gloss';
  if (/rough|(^|_)rgh(_|$)/.test(s)) return 'rough';
  if (/metal/.test(s)) return 'metal';
  if (/occlusion|(^|_)ao(_|$)|ambient_?occ/.test(s)) return 'ao';
  if (/emiss|glow|(^|_)emit(_|$)/.test(s)) return 'emis';
  if (/height|bump|displace|(^|_)disp(_|$)/.test(s)) return 'height';
  if (/diffus|albedo|base_?colou?r|(^|_)(col|color|colour|bc|dif|diff)(_|$)/.test(s)) return 'base';
  return '';
}
const KEYROLE = { map_kd: 'base', map_ke: 'emis', map_bump: 'normal', bump: 'normal', norm: 'normal', map_norm: 'normal', map_ns: 'rough', map_pr: 'rough', map_pm: 'metal', refl: 'metal', map_ao: 'ao' };

/* ------------------------------------------------------------------ pixel work */
function fitDims(w, h, max) { const s = Math.min(1, max / Math.max(w, h)); return [Math.max(1, Math.round(w * s)), Math.max(1, Math.round(h * s))]; }
function renormNormals(d) {
  for (let i = 0; i < d.length; i += 4) {
    const x = d[i] / 127.5 - 1, y = d[i + 1] / 127.5 - 1, z = d[i + 2] / 127.5 - 1, l = Math.hypot(x, y, z) || 1;
    d[i] = Math.round((x / l * .5 + .5) * 255); d[i + 1] = Math.round((y / l * .5 + .5) * 255); d[i + 2] = Math.round((z / l * .5 + .5) * 255); d[i + 3] = 255;
  }
}
/* glTF wants one texture: R = occlusion, G = roughness, B = metalness */
function packORM(w, h, ao, ro, me, invRough) {
  const o = new Uint8ClampedArray(w * h * 4);
  for (let j = 0; j < o.length; j += 4) {
    o[j] = ao ? ao[j] : 255; o[j + 1] = ro ? (invRough ? 255 - ro[j] : ro[j]) : 255; o[j + 2] = me ? me[j] : 0; o[j + 3] = 255;
  }
  return o;
}
function forceOpaque(d) { for (let i = 3; i < d.length; i += 4) d[i] = 255; }
function hasAlpha(d) { for (let i = 3; i < d.length; i += 4) if (d[i] < 250) return true; return false; }

/* ------------------------------------------------------------------ browser image backend */
function browserImages() {
  return {
    async load(bytes) {
      const blob = new Blob([bytes]); let bmp;
      try { bmp = await createImageBitmap(blob, { premultiplyAlpha: 'none', colorSpaceConversion: 'none' }); }
      catch (e) { bmp = await createImageBitmap(blob); }
      return {
        w: bmp.width, h: bmp.height,
        rgba(w, h) {
          const c = document.createElement('canvas'); c.width = w; c.height = h;
          const x = c.getContext('2d', { willReadFrequently: true });
          x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; x.drawImage(bmp, 0, 0, w, h);
          const d = x.getImageData(0, 0, w, h).data; c.width = c.height = 0; return d;
        },
        dispose() { if (bmp.close) bmp.close(); }
      };
    },
    async encode(rgba, w, h, mime, q) {
      const c = document.createElement('canvas'); c.width = w; c.height = h;
      c.getContext('2d').putImageData(new ImageData(rgba instanceof Uint8ClampedArray ? rgba : new Uint8ClampedArray(rgba.buffer, rgba.byteOffset, rgba.length), w, h), 0, 0);
      const b = await new Promise(r => c.toBlob(r, mime, q)); c.width = c.height = 0;
      if (!b) throw new Error('Could not encode a texture');
      return new Uint8Array(await b.arrayBuffer());
    }
  };
}

/* ------------------------------------------------------------------ GLB writer */
function BinBuilder() {
  const parts = []; let len = 0; const views = [];
  const pad = () => { const p = (4 - len % 4) % 4; if (p) { parts.push(new Uint8Array(p)); len += p; } };
  return {
    views,
    add(u8, target) { pad(); const v = { buffer: 0, byteOffset: len, byteLength: u8.length }; if (target) v.target = target; parts.push(u8); len += u8.length; views.push(v); return views.length - 1; },
    finish() { pad(); const out = new Uint8Array(len); let o = 0; for (const p of parts) { out.set(p, o); o += p.length; } return out; }
  };
}
function writeGlb(json, bin) {
  const js = new TextEncoder().encode(JSON.stringify(json)), jl = Math.ceil(js.length / 4) * 4, bl = Math.ceil(bin.length / 4) * 4;
  const out = new Uint8Array(12 + 8 + jl + 8 + bl), dv = new DataView(out.buffer);
  dv.setUint32(0, 0x46546C67, true); dv.setUint32(4, 2, true); dv.setUint32(8, out.length, true);
  dv.setUint32(12, jl, true); dv.setUint32(16, 0x4E4F534A, true); out.set(js, 20); out.fill(0x20, 20 + js.length, 20 + jl);
  const o = 20 + jl; dv.setUint32(o, bl, true); dv.setUint32(o + 4, 0x004E4942, true); out.set(bin, o + 8);
  return out;
}

/* ------------------------------------------------------------------ one OBJ -> one GLB */
async function buildGlb(objEntry, pool, mtlEntries, opts) {
  const st = opts.onStatus, IM = opts.images, notes = [], texInfo = [], stem = stemOf(objEntry.name);
  st('Reading ' + baseName(objEntry.name) + '…');
  const g = parseObj(new TextDecoder().decode(await objEntry.bytes()));
  const matNames = [...g.prims.keys()].filter(k => g.prims.get(k).length);

  /* materials file(s) */
  let mats = new Map();
  let mm = mtlEntries.filter(m => g.mtllibs.some(l => lower(baseName(l)) === lower(baseName(m.name))));
  if (!mm.length) mm = mtlEntries.filter(m => lower(stemOf(m.name)) === lower(stem));
  if (!mm.length && mtlEntries.length === 1) mm = mtlEntries;
  for (const m of mm) parseMtl(new TextDecoder().decode(await m.bytes())).forEach((v, k) => mats.set(k, v));

  /* geometry */
  const bin = BinBuilder(), accessors = [], missing = [];
  const acc = (view, ct, count, type, mn, mx) => { const a = { bufferView: view, componentType: ct, count, type }; if (mn) { a.min = mn; a.max = mx; } accessors.push(a); return accessors.length - 1; };
  const mn = [1e30, 1e30, 1e30], mx = [-1e30, -1e30, -1e30];
  for (let i = 0; i < g.pos.length; i += 3) for (let k = 0; k < 3; k++) { const v = g.pos[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
  const nv = g.pos.length / 3;
  const aP = acc(bin.add(u8of(g.pos), 34962), 5126, nv, 'VEC3', mn, mx), aN = acc(bin.add(u8of(g.nrm), 34962), 5126, nv, 'VEC3'), aU = acc(bin.add(u8of(g.uv), 34962), 5126, nv, 'VEC2');
  const small = nv < 65536; let tris = 0;
  const primitives = matNames.map((mname, mi) => {
    const idx = g.prims.get(mname), arr = small ? Uint16Array.from(idx) : Uint32Array.from(idx); tris += idx.length / 3;
    return { attributes: { POSITION: aP, NORMAL: aN, TEXCOORD_0: aU }, indices: acc(bin.add(u8of(arr), 34963), small ? 5123 : 5125, idx.length, 'SCALAR'), material: mi, mode: 4 };
  });

  /* textures */
  const images = [], textures = [], loaded = new Map(); const gltfMats = [];
  const loadImg = async e => { if (!loaded.has(e)) loaded.set(e, await IM.load(await e.bytes(), e.name)); return loaded.get(e); };
  const addTex = (bytes, mime) => { images.push({ bufferView: bin.add(bytes), mimeType: mime }); textures.push({ sampler: 0, source: images.length - 1 }); return textures.length - 1; };
  const poolByName = new Map(), poolByStem = new Map();
  pool.forEach(e => { poolByName.set(lower(baseName(e.name)), e); if (IMG_OK.includes(extOf(e.name)) && !poolByStem.has(lower(stemOf(e.name)))) poolByStem.set(lower(stemOf(e.name)), e); });
  const find = file => {                                  /* exact file name first, then same name with another extension (e.g. .tga in the .mtl, .png in the zip) */
    const e = poolByName.get(lower(file));
    if (e && IMG_OK.includes(extOf(e.name))) return e;
    return poolByStem.get(lower(file.replace(/\.[^.]+$/, ''))) || e || null;
  };
  let origMax = 0;

  for (const mname of matNames) {
    const def = mats.get(mname) || { name: mname, maps: [] }, role = {};
    const setRole = (r, entry) => { if (r && r !== 'height' && r !== 'gloss' && !role[r]) role[r] = { e: entry, inv: false }; if (r === 'gloss' && !role.rough) role.rough = { e: entry, inv: true }; };
    for (const [key, file] of def.maps) {
      const e = find(file);
      if (!e) { notes.push('Texture not found in the upload: ' + file); missing.push(file); continue; }
      if (!IMG_OK.includes(extOf(e.name))) { notes.push(baseName(e.name) + ': browsers can\'t read ' + extOf(e.name) + ' files - convert it to .png and upload again'); missing.push(file); continue; }
      const byName = classify(stemOf(file));
      if (byName === 'height' && (key === 'map_bump' || key === 'bump')) { notes.push(file + ' looks like a height/bump map, not a normal map - skipped'); continue; }
      setRole(byName || KEYROLE[key] || '', e);
    }
    /* fill gaps from file names (only when it's unambiguous which model they belong to) */
    const sole = matNames.length === 1;
    for (const r of ['base', 'normal', 'rough', 'metal', 'ao', 'emis']) {
      if (role[r]) continue;
      const cand = pool.filter(e => IMG_OK.includes(extOf(e.name)) && (() => { const c = classify(stemOf(e.name)); return c === r || (r === 'rough' && c === 'gloss'); })() &&
        (sole || lower(stemOf(e.name)).startsWith(lower(stem)) || lower(stemOf(e.name)).includes(lower(mname))));
      if (cand.length) { const c = classify(stemOf(cand[0].name)); role[r] = { e: cand[0], inv: c === 'gloss' }; }
    }

    const m = { name: mname, pbrMetallicRoughness: {} }, P = m.pbrMetallicRoughness;
    const kd = def.kd || [.8, .8, .8], alpha = def.d === undefined || isNaN(def.d) ? 1 : def.d;
    const sizeOf = async (e) => { const im = await loadImg(e), d = fitDims(im.w, im.h, opts.maxTex), sc = d[0] !== im.w || d[1] !== im.h; if (sc) origMax = Math.max(origMax, im.w, im.h); return { im, w: d[0], h: d[1], scaled: sc }; };
    const report = (r, e, w, h, b) => texInfo.push({ role: r, file: baseName(e.name), w, h, bytes: b.length });

    if (role.base) {
      st('Texture: base colour…'); const { im, w, h } = await sizeOf(role.base.e), d = im.rgba(w, h), a = hasAlpha(d);
      let b;
      if (a) { b = await IM.encode(d, w, h, 'image/png'); m.alphaMode = 'MASK'; m.alphaCutoff = .5; notes.push(baseName(role.base.e.name) + ' has transparency - exported as a cut-out'); }
      else { forceOpaque(d); b = await IM.encode(d, w, h, 'image/jpeg', .9); }
      P.baseColorTexture = { index: addTex(b, a ? 'image/png' : 'image/jpeg') }; report('base colour', role.base.e, w, h, b);
      P.baseColorFactor = [1, 1, 1, alpha];
    } else P.baseColorFactor = [kd[0], kd[1], kd[2], alpha];
    if (alpha < .99 && !m.alphaMode) m.alphaMode = 'BLEND';

    if (role.normal) {
      st('Texture: normal map…'); const { im, w, h, scaled } = await sizeOf(role.normal.e), d = im.rgba(w, h);
      if (scaled) renormNormals(d); else forceOpaque(d);
      const b = await IM.encode(d, w, h, 'image/png'); m.normalTexture = { index: addTex(b, 'image/png') }; report('normal', role.normal.e, w, h, b);
    }
    if (role.rough || role.metal || role.ao) {
      st('Texture: roughness / metal…');
      const parts = [role.ao, role.rough, role.metal].filter(Boolean), dims = [];
      for (const p of parts) dims.push(await sizeOf(p.e));
      const w = Math.max(...dims.map(x => x.w)), h = Math.max(...dims.map(x => x.h));
      const px = r => role[r] ? loaded.get(role[r].e).rgba(w, h) : null;
      const d = packORM(w, h, px('ao'), px('rough'), px('metal'), role.rough && role.rough.inv);
      const b = await IM.encode(d, w, h, 'image/png'), ti = addTex(b, 'image/png');
      if (role.rough || role.metal) { P.metallicRoughnessTexture = { index: ti }; }
      if (role.ao) m.occlusionTexture = { index: ti };
      ['ao', 'rough', 'metal'].forEach(r => { if (role[r]) report(r === 'ao' ? 'occlusion' : r === 'rough' ? 'roughness' : 'metallic', role[r].e, w, h, b); });
    }
    P.metallicFactor = role.metal ? 1 : 0; P.roughnessFactor = role.rough ? 1 : .6;
    if (role.emis) {
      st('Texture: emissive…'); const { im, w, h } = await sizeOf(role.emis.e), d = im.rgba(w, h); forceOpaque(d);
      const b = await IM.encode(d, w, h, 'image/jpeg', .9); m.emissiveTexture = { index: addTex(b, 'image/jpeg') }; m.emissiveFactor = [1, 1, 1]; report('emissive', role.emis.e, w, h, b);
    }
    gltfMats.push(m);
  }
  loaded.forEach(im => im.dispose && im.dispose());
  if (origMax) notes.unshift('Textures scaled down from ' + origMax + ' px to ' + opts.maxTex + ' px');

  const json = {
    asset: { version: '2.0', generator: 'Strike Zone zip2glb' },
    scene: 0, scenes: [{ nodes: [0] }], nodes: [{ name: stem, mesh: 0 }], meshes: [{ name: stem, primitives }],
    materials: gltfMats, accessors, bufferViews: bin.views
  };
  if (textures.length) {
    json.samplers = [{ magFilter: 9729, minFilter: 9987, wrapS: 10497, wrapT: 10497 }];
    json.textures = textures; json.images = images;
  }
  const bytes = bin.finish(); json.buffers = [{ byteLength: bytes.length }];
  return { name: stem, bytes: writeGlb(json, bytes), info: { triangles: tris, vertices: nv, textures: texInfo, notes, missing } };
}

/* ------------------------------------------------------------------ public: whole bundle */
async function convert(entries, options) {
  const opts = Object.assign({ maxTex: 2048, onStatus() {}, passthrough: ['.glb'], images: null }, options || {});
  if (!opts.images) opts.images = browserImages();
  const out = [];
  let objs = entries.filter(e => extOf(e.name) === '.obj');
  const noQuad = objs.filter(e => !/quad/i.test(baseName(e.name)));
  if (noQuad.length && noQuad.length < objs.length) objs = noQuad;           /* "_quads" copies are duplicates of the triangulated model */
  for (const e of entries) if (opts.passthrough.includes(extOf(e.name)))
    out.push({ name: baseName(e.name), bytes: await e.bytes(), passthrough: true, info: { notes: [] } });
  const pool = entries.filter(e => IMG_OK.includes(extOf(e.name)) || IMG_BAD.includes(extOf(e.name))), mtls = entries.filter(e => extOf(e.name) === '.mtl');
  for (const o of objs) {
    const r = await buildGlb(o, pool, mtls, opts);
    out.push(r);
  }
  if (!out.length) throw new Error('No .obj model found. Include the .obj (and its texture maps) in the zip.');
  return out;
}

const api = { readZip, expandFiles, convert, parseObj, parseMtl, classify, packORM, renormNormals, fitDims };
if (typeof module !== 'undefined' && module.exports) module.exports = api;
root.Zip2Glb = api;
})(typeof window !== 'undefined' ? window : globalThis);
